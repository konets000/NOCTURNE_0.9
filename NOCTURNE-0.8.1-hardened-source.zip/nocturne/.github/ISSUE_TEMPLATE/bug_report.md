---
name: Bug report
about: Report a reproducible problem with NOCTURNE
title: "[Bug]: "
labels: bug
assignees: ''
---

## Summary

Describe the problem in a few sentences.

## Steps to reproduce

1. 
2. 
3. 

## Expected behaviour

What did you expect to happen?

## Actual behaviour

What happened instead? Include the full error text if available.

## Environment

- NOCTURNE version / source commit:
- Platform (Android or Windows):
- OS/device version:
- Install source (CI artifact or local build):

## Checks

- [ ] I used synthetic examples and removed personal information.
- [ ] I checked existing issues for duplicates.
