---
name: Feature request
about: Suggest a focused improvement to NOCTURNE
title: "[Feature]: "
labels: enhancement
assignees: ''
---

## Problem or use case

What are you trying to do, and what is difficult today?

## Proposed change

Describe the behaviour you would like to see.

## Alternatives considered

What other approaches have you considered?

## Platform impact

- [ ] Android
- [ ] Windows
- [ ] Shared reader / dictionary logic
