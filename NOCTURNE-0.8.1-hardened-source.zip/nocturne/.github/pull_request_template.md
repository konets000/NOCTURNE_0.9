## Summary

Describe what changed and why.

## Validation

- [ ] `sh tests/run-tests.sh`
- [ ] Android build checked (if affected)
- [ ] Windows runtime/package checked (if affected)
- [ ] Documentation and third-party attribution updated (if affected)

## Risk and limitations

Describe any behaviour changes, privacy implications, or platform checks not completed. Confirm that no secrets, private media, or generated build outputs are included.
